#ifndef __PLUMED_config_version_h
#define __PLUMED_config_version_h
#define PLUMED_VERSION_SHORT "2.8"
#define PLUMED_VERSION_LONG "2.8.1"
#define PLUMED_VERSION_GIT "Unknown"
#define PLUMED_VERSION_MAJOR 2
#define PLUMED_VERSION_MINOR 8
#define PLUMED_VERSION_PATCH 1
#endif
