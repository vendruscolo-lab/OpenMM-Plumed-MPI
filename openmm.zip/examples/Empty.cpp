// This empty C++ source file is just used to 
// trick CMake into linking with C++ libraries
// when building a C main program statically.
